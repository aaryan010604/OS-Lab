#!/bin/bash

# Read a number from user
echo "Enter a number:"
read num

# Check if number is even or odd
if [ $((num % 2)) -eq 0 ]
then
    echo "$num is Even"
else
    echo "$num is Odd"
fi